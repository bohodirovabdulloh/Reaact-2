import React from 'react'

const MyProjects = () => {
  return (
    <div>MyProjects</div>
  )
}

export default MyProjects