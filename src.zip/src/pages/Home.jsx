import React, { useEffect } from 'react'
import Navbar from '../components/Navbar'
import HomeProfile from '../components/HomeProfile'
import ThemeControler from '../components/ThemeControler'

const Home = () => {

  useEffect(() => {
   document.querySelector('html').setAttribute('data-theme', 'dark')
  }, [])
  

  return (
    <>
    <header className='container mx-auto max-w[80%] flex gap-5 '> 
    <Navbar/>
    <HomeProfile/>
    <ThemeControler/>
    </header>
    <main>

    </main>
    <footer>

    </footer>
    </>
  )
}

export default Home