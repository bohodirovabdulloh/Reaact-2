import React from 'react'
import { Link } from 'react-router-dom'
import { FaInstagramSquare } from "react-icons/fa";
import { FaTelegram } from "react-icons/fa";

const Navbar = () => {
  return (
   <nav className='flex items-center justify-between py-10 flex-col h-full w-1/5 shadow-lg shadow-sky-400 rounded-2xl'>
    <Link to="/">
    <img src="./logo.png" alt="" className='size-40' />
    </Link>

    <ul className='flex flex-col gap-5' >
        <li className='list-item hover:text-primary hover:scale-105 transition-all'>
            <Link to="/">Home</Link>
        </li>
        <li className='list-item hover:text-primary hover:scale-105 transition-all'>
            <Link to="/about">About</Link>
        </li>
        <li className='list-item hover:text-primary hover:scale-105 transition-all'>
            <Link to="/my-projects">My projects</Link>
        </li>
        <li className='list-item hover:text-primary hover:scale-105 transition-all'>
            <Link to="/contact">Contact</Link>
        </li>
    </ul>
    <div className='flex mt-10 gap-5 '>
        <Link>
        <FaInstagramSquare />
        </Link>

        <Link>
        <FaTelegram />
        </Link>

    </div>
   </nav>
)
}

export default Navbar