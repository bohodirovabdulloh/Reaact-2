import React from 'react'

const HomeProfile = () => {
  return (
    <div className='w-4/5'>
      <div className='flex justify-between items-center w-full border-2 border-sky-400 p-10 rounded-3xl shadow-inner shadow-sky-400'>
        <img
         className='size-64 border-sky-400 border-2 rounded-2xl shadow-lg shadow-sky-400'
         src="./photo.png" 
         alt=""
          />
          <div>
            <h1 className='text-sky-400 text-4xl'>Ibrokhim Juraev</h1>
            <p className='text-warning text-xl text-right'>Front-End Developer</p>
          </div>
      </div>
      <div></div>
    </div>
  )
}

export default HomeProfile